export default {
  id: "At Last",
  name: "At Last",

  images: [
    "/src/images/At Last/Screenshot 2026-07-01 at 2.45.52 AM.png",
  ],

  videoIds: [
    "UiPVbzn-Va0",
  ],

  biography: [
    { text: "At Last was a vocal group from Season 1 of America's Got Talent. They finished the competition in the Bottom 5 of the Top 10 in the Finals. At Last, which consisted of Hans Cho, Michael H. Lee, Justin Fong, and DJ Say, has performed with their new old school style called 'hip-hopapella', mixing tight R&B harmonies with hip hop beats. Influenced by the sounds of classic icons such as Stevie Wonder, Al Green, The Temptations and modern day artists Boyz II Men and Alicia Keys, they write, produce and arrange their own music.", indent: true },
    { text: "Based out of Los Angeles, CA, it was the love of music and singing that brought the four of them together along with the help and vision of actress Ming-Na and producer Eric Zee. They represent the many diverse cultures of Asian-Americans, including Chinese, Korean and Cambodian and all are very proud of their Asian-American heritage. They are also all bilingual.", indent: true },
    { text: "At Last has appeared in concerts with Justin Timberlake, Destiny's Child and Boyz II Men, and have performed on such noted shows as \"It's Showtime at the Apollo\", Ed McMahon's \"Next Big Star\" and \"The Wayne Brady Show\". They have guest starred on Nickelodeon's top show, \"Drake and Josh\", and the number 1 show on ABC Family, \"Switched Up\". At Last also recorded the title track to the Kids WB's animated series, \"Krypto the Superdog.\"", indent: true },
  ],

  albums: [
    { title: "Unreleased EP", year: 1996, link: "https://music.youtube.com/watch?v=UiPVbzn-Va0" },
  ]
}
