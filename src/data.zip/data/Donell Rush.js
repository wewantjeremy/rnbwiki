export default {
  id: "Donell Rush",
  name: "Donell Rush",

  images: [
    "/src/images/Donell Rush/Donell Rush_2.jpg",
    "/src/images/Donell Rush/Donell Rush_3.jpg",
  ],

  videoIds: [
    "celSGsPOc0k",
    "yd-ny6Ehjc0",
    "A-zuTtuuMd8",
    "EG0TI_51OMs",
    "M7MIjgXoPys",
    "4scUQEi8on8",
    "XmcU6BoQ2iQ",
  ],

  biography: [
    { text: "Donell Rush (September 12, 1960 – March 22, 1996) was an American R&B singer, who was signed to RCA Records in the 1990s. He scored a Top 10 hit in the US Billboard Hot Dance Club Play chart with the song \"Symphony\", from his debut album, Comin' & Goin. \"Symphony\" peaked at No. 66 in the UK Singles Chart in December 1992. He scored another minor hit with \"Let's Get Intimate\" featuring Chantay Savage in 1992.", indent: true },
    { text: "Rush's health had declined significantly shortly after completing his debut album which partially contributed to its cancelation, though he remained private about his condition. Rush died on March 22, 1996 after suffering from a pulmonary embolism. His last recording \"Shout N Out\" with Lood was recorded 6 days before his death.", indent: true },
  ],

  albums: [
    { title: "Comin' & Goin'", year: 1993, link: "https://music.youtube.com/playlist?list=PLVsmyNZ-gQcA" },
  ]
}
