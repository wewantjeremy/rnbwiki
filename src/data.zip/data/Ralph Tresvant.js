export default {
  id: "Ralph Tresvant",
  name: "Ralph Tresvant",

  images: [
    "/src/images/Ralph Tresvant/Ralph Tresvant_27.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_35.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_36.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_38.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_40.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_41.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_45.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_46.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_7.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_8.jpg",
    "/src/images/Ralph Tresvant/Ralph Tresvant_9.jpg",
  ],

  videoIds: [
    "0RstxV4Iqas",
    "xhfhVSUCLY4",
    "PjBr8Hkttbo",
    "jWMpoMgi9WI",
    "U_xwcj2qyDQ",
    "bohcjo6pNqY",
    "taBYKUyamgk",
    "5O3RVQlkqbg",
  ],

  biography: [
    { text: "Ralph Edward Tresvant (born May 16, 1968) is an American R&B singer, songwriter, and record producer, best known as the lead singer of R&B group New Edition. As a solo artist, Tresvant released his double platinum-selling debut album Ralph Tresvant (1990). In 2008, he began touring with Bobby Brown and Johnny Gill in a new group named Heads of State. On February 3, 2023, Tresvant became host of the syndicated radio show Love and R&B, heard on WOSF.", indent: true },
    { text: "Tresvant was born on May 16, 1968, in the Roxbury section of Boston, Massachusetts, the son of Patricia Tresvant and Ralph Hall. Tresvant grew up enjoying music with his younger siblings, sister LaTonya and brother Andre. When some junior high school friends got the idea to put a group together, Tresvant and three others – Bobby Brown, Ricky Bell and Michael Bivins – started performing at local talent shows. They were spotted by a local up-and-coming producer and songwriter, Brooke Payne, a local manager and choreographer, who encountered the boys at a local talent show in Roxbury.", indent: true },
    { text: "After an audition for Payne, he gave them the name New Edition to signify they were a new edition of the Jackson 5. Maurice Starr, who wanted to create a \"newer edition\" of the pop act The Jackson 5, signed them to his independent Streetwise Records label and a fifth member, Ronnie DeVoe (Payne's nephew), was added to the group. Releasing their debut album, Candy Girl, in 1983. The album was a successful launching pad for the group, spawning the teen-oriented hit singles \"Popcorn Love,\" \"Is This the End,\" \"Jealous Girl\" and the title track. [citation needed]", indent: true },
    { text: "After a dispute over money, New Edition left Starr's management and record label and signed with major label MCA Records, which released the group's self-titled second album. Tresvant's smooth, approachable vocal style had become a signature for the group, and the hits continued, including the Top Five smash single \"Cool It Now.\"", indent: true },
    { text: "Quiet and shy, Tresvant was initially apprehensive about the idea of recording a solo project. Tresvant felt the members of the group were not showing him the acknowledgment that he thought he deserved. However, after witnessing the huge success of Bobby Brown's solo albums and of Ronnie DeVoe, Ricky Bell and Michael Bivins'Bell Biv DeVoe side project, Tresvant eventually relented. His self-titled debut was released in 1990. The lead single \"Sensitivity\" spent 20 weeks on the U.S. R&B Singles chart, including two weeks at Number One. The album also included the Top 5 hit singles \"Do What I Gotta Do\" and \"Stone Cold Gentleman\", the latter of which features guest vocals from former band member Bobby Brown. Tresvant's self-titled debut album sold two million copies, achieving double-platinum status. Tresvant won the Billboard Music Award for \"No. 1 New Pop Male Artist\" in 1991.", indent: true },
    { text: "Tresvant's vocals were also featured on songs on the soundtracks for the films Mo' Money (\"Money Can't Buy You Love\") and The Preacher's Wife (\"Somebody Bigger Than You and I\"). He made a cameo appearance in the popular urban comedy House Party 2 which featured his two singles for the film's soundtrack, \"Rated-R\" and \"Yo Baby Yo\".", indent: true },
    { text: "Tresvant was a radio show DJ on WZBR. The show Inside the Ride with Ralph Tresvant premiered on September 5, 2016. In 2023, he took over hosting duties of Radio One's Love and R&B radio show from former label mate, Al B. Sure!", indent: true },
  ],

  albums: [
    { title: "Ralph Tresvant", year: 1990, link: "https://music.youtube.com/browse/MPREb_3F1bCyi4Akd" },
    { title: "It's Goin' Down", year: 1993, link: "https://music.youtube.com/browse/MPREb_hcBOQzvOkOY" },
    { title: "RizzWaFaire", year: 2006, link: "https://music.youtube.com/browse/MPREb_KnRnInnbEMT" },
  ]
}
