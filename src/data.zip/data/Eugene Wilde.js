export default {
  id: "Eugene Wilde",
  name: "Eugene Wilde",

  images: [
    "/src/images/Eugene Wilde/thumbnail.jpeg",
  ],

  videoIds: [
    "a5W6VrV_7RI",
    "fKHtWAFTYc0",
    "JbWDcLOHmqI",
    "J-4zGtQWGjA",
  ],

  biography: [
    { text: "Eugene Wilde (born Ronald Eugene Broomfield on December 6, 1961 in North Miami Beach, Florida) is an R&B music singer from the ’80s.", indent: true },
    { text: "Eugene was raised in Miami, Florida and grew up in a musical family. He first began singing when he was 5 years old. As he got older, he joined his family’s music group, La Voyage where they played in local clubs.", indent: true },
    { text: "In the ’70s, the group changed their name to Tight Connection and later Simplicious. He was also a member of the music group, Today, Tomorrow, Forever, whom he recorded an album with.", indent: true },
    { text: "Eugene’s manager insisted that he go by his middle name professionally; he took his last name from an advertisement for a club in New York named Wildflower’s. In 1984, he signed a record deal with Philly World Records and released his self-titled debut studio album during that same year.", indent: true },
    { text: "The album peaked at #97 on the Billboard 200, #14 on Billboard’s R&B Albums chart and #67 on the U.K. Albums chart. The lead single, “Gotta Get You Home Tonight” became his first number-one R&B hit, topping Billboard’s Hot Black Singles chart for a week in January of 1985, staying on the chart for 23 weeks. It also crossed over to the pop music charts where it peaked at #83 on the Billboard Hot 100 and #18 on the U.K. Singles chart.", indent: true },
    { text: "The follow-up single, “Rainbow” peaked at #22 on Billboard’s Hot Black Singles chart, staying on the chart for 15 weeks. The third single, “Personality” peaked at #34 on the U.K. Singles chart for 6 weeks. The last single released from the album, “Chey Chey Kulé” peaked at #83 on the U.K. Singles chart and #69 on Billboard’s Hot Black Singles chart, staying on the chart for 7 weeks. In 1985, Eugene released his sophomore album, “Serenade” which peaked at #17 on Billboard’s R&B Albums chart. The first single, “Don’t Say No (Tonight)” topped Billboard’s Hot Black Singles chart for 3 weeks, staying on the chart for 22 weeks. It also peaked at #76 on the Billboard Hot 100 and #80 on the U.K. Singles chart.", indent: true },
    { text: "The follow-up single, “Diana” peaked at #10 on Billboard’s Hot Black Singles chart, staying on the chart for 15 weeks. The third and last single, “30 Mins. To Talk” peaked at #79 on Billboard’s Hot Black Singles chart, staying on the chart for only 4 weeks. During that same year, Eugene appeared in the film, “Rappin’” and was featured on the film’s soundtrack with the track, “First Love Never Dies” with singer Joanna Gardner. After Philly World Records folded, Eugene’s career came to a brief halt. In 1987, he recorded a duet with Sheena Easton called “What If We Fall in Love” which was featured on Sheena’s album, “No Heart But a Sound.” He also appeared on music group Cabo Frio’s self-titled album.", indent: true },
    { text: "In 1989, he released his third studio album, “I Choose You (Tonight)” on MCA Records. The lead single, “I Can’t Stop (This Feeling)” peaked at #35 on Billboard’s Hot Black Singles chart, staying on the chart for 9 weeks. The second single, “Ain’t Nobody’s Business” peaked at #50 on Billboard’s Hot Black Singles chart, staying on the chart for 9 weeks. The title song peaked at #17 on Billboard’s Hot Black Singles chart, staying on the chart for 9 weeks. Eugene later ran an independent record label in Florida called Wilde City Records.", indent: true },
    { text: "In 1992, Eugene released his fourth studio album, “How About Tonight” which didn’t make the charts. The title song peaked at #17 on Billboard’s Hot R&B Singles chart, staying on the chart for 13 weeks. The follow-up single, “Special Feelings” didn’t make the charts. In 1994, he was featured on his sister, Dee Dee Wilde’s album, “I Am A Woman”.", indent: true },
    { text: "During the ’90s and 2000s, Eugene began focusing on songwriting for artists such as Backstreet Boys, Marc Dorsey, Kathie Lee Gifford, Britney Spears and Victoria Beckham. In 2010, he provided vocals for Danish production duo Rob Hardt and Frank Ryle’s song, “Back for More”. In 2011, Eugene released his fifth studio album, “Get Comfortable” independently. According to research, he runs a record label, 50ish Music Group.", indent: true },
  ],

  albums: [
    { title: "I Choose You (Tonight)", year: 1989, link: "https://music.youtube.com/browse/MPREb_bcvVvwopzTL" },
    { title: "How About Tonight", year: 1992, link: "https://music.youtube.com/browse/MPREb_qeDmG773DlI" },
    { title: "Hits Anthology", year: 2007, link: "https://music.youtube.com/browse/MPREb_0QM7dvYWOgQ" },
    { title: "Eugene Wilde (Digitally Remastered)", year: 2010, link: "https://music.youtube.com/browse/MPREb_Px8zGF8DbZS" },
    { title: "Serenade (Digitally Remastered)", year: 2010, link: "https://music.youtube.com/browse/MPREb_RreyCWsw2wX" },
    { title: "Get Comfortable", year: 2011, link: "https://music.youtube.com/browse/MPREb_0X9m9LAOCKH" },
  ]
}
