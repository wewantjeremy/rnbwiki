export default {
  id: "DREAM",
  name: "DREAM",

  images: [
    "/src/images/DREAM/Dream_Girl_Group_2016.jpg",
    "/src/images/DREAM/Dream_ItWasAllADream.jpg",
    "/src/images/DREAM/Dream_Reality.jpg",
    "/src/images/DREAM/DreamThisisMe.jpg",
  ],

  videoIds: [
    "IDjI3SD4Cr4",
    "7zT2cTC1VzU",
    "PR1xUKobnIs",
  ],

  biography: [
    { text: "Dream was a pop/R&B girl group from Los Angeles. The original line-up consisted of Ashley Poole (born Ashley Nicole Poole on May 10, 1985 in Blythe, California), Holly Blake-Arnstein (born on August 3, 1985 in Hollywood, California), Melissa Schuman (born Melissa Amber Schuman on August 21, 1984 in San Clemente, California) and Alex Chester (born on December 28, 1984).", indent: true },
    { text: "The group was formed in 1998 by talent scout Judith Fontaine and their original name was First Warning, but was later changed to Dream. Later, the girls left Judith and were signed by Sean “Diddy” Combs to Bad Boy Records. In 1999, Alex was replaced by new member Diana Ortiz (born on September 23, 1985 in San Fernando Valley, California). Judith sued Diddy, Holly, Melissa and Ashley, but she lost her case. In September of 2000, Dream released their debut single “He Loves U Not” which became a hit, peaking at #2 on the Billboard Hot 100, #3 on Billboard’s Top 40 Mainstream chart, #5 on Billboard’s Top 40 Tracks chart, #47 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart, #9 on Billboard’s Rhythmic Top 40 chart, #33 on Billboard’s Latin Tropical/Salsa Airplay chart and #15 on Billboard’s Hot R&B/Hip-Hop Singles & Tracks chart, staying on the chart for 17 weeks.", indent: true },
    { text: "The music video for the single peaked at #2 on MTV’s TRL (Total Request Live) and became the first video by an all-female group to be retired on TRL after spending 65 days on the show’s countdown. In January of 2001, the group released their debut album “It Was All a Dream” which peaked at #6 on the Billboard 200, #11 on Billboard’s R&B Albums chart and #15 on Billboard’s Top Internet Albums chart. In May of 2001, Dream released their follow-up single “This is Me” which peaked at #39 on the Billboard Hot 100, #13 on Billboard’s Top 40 Mainstream chart, #17 on Billboard’s Top 40 Tracks chart, #5 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart and #80 on Billboard’s Hot R&B/Hip-Hop Singles & Tracks chart, staying on the chart for 10 weeks. The remixed version of the song featured rapper Kain and Diddy.", indent: true },
    { text: "In order to promote the album, Dream toured with *NSYNC on their “No Strings Attached” tour and on the MTV TRL Tour with artists such as Destiny’s Child, Jessica Simpson, 3LW, Eve and Nelly. They also made appearances on television shows such as “Good Morning America,” “Live With Regis & Kelly,” “The Rosie O’Donnell Show,” “The Early Show” and “TRL.”", indent: true },
    { text: "The group was also featured on the MTV show “Cribs” and even had dolls made by Play Along Toys.", indent: true },
    { text: "The songs “Miss You” and “In My Dreams” were planned to be released as the third & fourth singles from the album, but they were cancelled due to the events of September 11, 2001.", indent: true },
    { text: "In April of 2002, Melissa left the group to pursue acting and was replaced by Kasey Sheridan (born on December 28, 1986). The group began working on their sophomore album and in the summer of 2003, they returned to the music scene with a more sexier image. During that same year, Dream released the lead single from their second album “Krazy” (featuring rapper Loon), but the single & music video failed to make any impact at all. The follow-up single from the album “That’s OK” was shelved. Dream’s second album “Reality” was scheduled to be released in the fall of 2003, but it kept being postponed. Later on, their record label dropped the group & Dream broke up, even though it was never formally announced. The album was digitally available through French Virgin Megastores in September of 2005.", indent: true },
    { text: "In May of 2008, it was released on iTunes in the United States. During that same month, two albums by the group: “Daddy’s Little Girl” and “Dream Never Land” were digitally released. The albums consisted of songs that featured original member Alex Chester.", indent: true },
    { text: "In an MTV News article in April of 2006, Holly noted that the sexier image of Dream that was pushed by Diddy and their management wasn’t a welcome change and she & the other girls were no longer enjoying the experience and the music.", indent: true },
    { text: "In January of 2008, Melissa announced that she and Ashley were starting a new band under a new name after a failed attempt to reunite the original line-up of Dream. It was also announced that there would be a reality show documenting their auditions for new members to add to the group.", indent: true },
    { text: "In July of 2008, the band’s name was revealed to be Lady Phoenix. A month later, Diana joined the band. Nothing much was heard about Lady Phoenix until 2012 when Melissa confirmed that they had disbanded after Ashley left the band and their reality show wasn’t picked up by any networks.", indent: true },
    { text: "These days, Melissa is married with a child. As an actress, she appeared in films such as “Love Don’t Cost a Thing” and “The Hollow.” After leaving Dream, she had plans to release a solo album, but they were scrapped. In November of 2010, her unreleased album “Stereotyped” and a single “Don’t” was released on iTunes.", indent: true },
    { text: "Ashley is pursuing a solo music career. Diana is a food & beverage manager (according to Bustle.com). Holly joined a band called Whirl Magnet and these days, she reportedly lives in San Francisco, is married and works as an occupational therapist.", indent: true },
    { text: "Alex Chester is still active as a performer. It’s unknown what Kasey Sheridan is up to these days.", indent: true },
  ],

  albums: [
    { title: "It Was All A Dream", year: 2001, link: "https://music.youtube.com/playlist?list=OLAK5uy_m0ngl-EnkQX2t_KCM-bab6i3iaqTTE-zo" },
  ]
}
