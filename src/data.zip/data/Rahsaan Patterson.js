export default {
  id: "Rahsaan Patterson",
  name: "Rahsaan Patterson",

  images: [
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_1.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_19.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_33.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_4.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_41.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_49.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_55.jpg",
    "/src/images/Rahsaan Patterson/Rahsaan Patterson_59.jpg",
  ],

  videoIds: [
    "u1Uv_bdHB0M",
    "ttvYb6wcJSU",
    "Ha1UDuK8kI8",
    "71mwQm-FUzM",
    "7UijBsJLKcw",
    "rrz12QGPigs",
    "CURKGHAD2yQ",
    "xwFtmoFkWMo",
  ],

  biography: [
    { text: "Rahsaan Patterson (born January 11, 1974) is an American singer and actor, best known for portraying \"The Kid\" on the 1980s television show Kids Incorporated.", indent: true },
    { text: "After appearing in a school talent show in 1983, Patterson auditioned for the television show Kids Incorporated. He was cast as \"The Kid\", and remained on the show for the next few years, appearing alongside such future stars as Fergie, Renee Sands, Martika, Mario Lopez and Shanice.", indent: true },
    { text: "After Kids Incorporated, Patterson gained experience as a backup vocalist for several artists (including Kids co-star Martika). Following his vocal contributions on Colour Club's self-titled album, as well as writing for other artists (his credits include Brandy's platinum Top 5 smash \"Baby\", and Tevin Campbell's hit \"Back to the World\").", indent: true },
    { text: "Patterson signed with MCA Records in 1995. Collaborating with Keith Crouch and Jamey Jaz, Ira Schickman, among others, released his self-titled debut album on January 28, 1997. The album peaked at No. 48 on Billboard's Top R&B/Hip-Hop Albums Chart.", indent: true },
    { text: "There were two singles released, \"Stop By\" and \"Where You Are\" peaked at No. 53 on Billboard's Hot R&B/Hip-Hop Songs chart.", indent: true },
    { text: "Receiving positive reviews from critics, the album failed to find a large audience (the single \"Where You Are\" did receive attention on R&B radio, and it appeared on the soundtrack to the 1996 Bulletproof). Patterson did, however, develop a loyal following both in the U.S. and abroad.", indent: true },
    { text: "Patterson went to work on his followup, Love in Stereo, with Jamey Jaz and new collaborators such as Van Hunt. When Love in Stereo was released in late 1999 it received better reviews than its predecessor, although the mainstream overlooked it. The album peaked at No. 51 on Billboard s Top R&B/Hip-Hop Albums Chart and two singles, \"The Moment\" and \"Treat You Like A Queen\" which peaked at no. 61 on Billboard s Hot R&B/Hip-Hop Songs. Rahsaan toured in support of Stereo playing dates throughout the U.S. and Europe.", indent: true },
    { text: "Although Patterson and MCA parted ways, he remained busy, continuing to perform live, working as a session singer, and contributing to both soundtracks (Brown Sugar) and compilation albums (Steve Harvey's Sign of Things to Come), while working on the next album.", indent: true },
    { text: "Patterson's third album, After Hours was released internationally in April 2004, garnering positive reviews. With the forming of his own label, After Hours was released in the U.S. in late October. The album debuted at No. 65 on Billboard's Top R&B/Hip-Hop Albums chart. The singles, \"So Hot\", \"April's Kiss\" and \"Forever Yours\" were issued but failed to chart on Billboard. Further collaborative efforts followed.", indent: true },
    { text: "Patterson's album, Wines & Spirits (again featuring collaborations with Crouch and Jaz) was released September 24, 2007, and debuted at No. 42 on Billboard s Top R&B/Hip-Hop Albums, his highest charted to date and No. 45 on Independent Albums Chart. The singles released, \"Stop Breaking My Heart\" and \"Feels Good\" charted on Billboard's Hot R&B/Hip-Hop Songs both at no. 59 and the later no. 76. A close friend, R&B singer Ledisi, in which he's also featured on her album Lost & Found, explains the genius of Patterson as, \"Rahsaan's greatest artistic strength is his ability to be overly honest in his recordings and in his live performances. If I had to sum him up in one word, I would call him'uninhibited'.\"", indent: true },
    { text: "In August 2008, Patterson released a Christmas album, The Ultimate Gift, by November Patterson won a BET J award for Underground Artist of the year.", indent: true },
    { text: "In 2008, Patterson joined with Australian-born producer/multi-instrumentalist/songwriter Jarrad'Jaz' Rogers and Copenhagen-based electro-soul singer Ida Corr to form the London-based alternative soul/pop/funk trio SugaRush Beat Company, who released their self-titled album through RCA (UK) in the summer of 2008.", indent: true },
    { text: "After the release of Wines and Spirits, Rahsaan resumed touring throughout the U.S. and overseas, and working with several recording artists. On December 14, 2010, a new song was available on iTunes, \"Easier Said Than Done\", a slow funk groove aimed as the lead single from his new album. On February 12, 2011, he performed at B.B. King's Blues Club to a sold out crowd, the show received rave reviews. In March 2011, after a concert in Ram's Head Tavern in Annapolis, MD, Patterson spoke about his album, Bleuphoria during a brief interview for thesoulcialista.", indent: true },
    { text: "In 2019, Rahsaan released the new single \"Sent from Heaven\" and announced his new album Heroes & Gods will release on May 17 that year.", indent: true },
    { text: "Patterson is openly gay. In a 2008 discussion about being a gay artist with LGBT -centric network Logo, for example, he said \"For me, it's not about being'the gay artist'; I'm an artist.\" In an interview with BET's Daily Voice, Patterson further clarified that \"I've never been in the closet or hiding anything.\"", indent: true },
  ],

  albums: [
    { title: "Rahsaan Patterson", year: 1997, link: "https://music.youtube.com/browse/MPREb_2F2gqJj3eQ9" },
    { title: "Love In Stereo", year: 1999, link: "https://music.youtube.com/browse/MPREb_hkF9XNiFzu1" },
    { title: "After Hours", year: 2004, link: "https://music.youtube.com/browse/MPREb_lFSBY5Q87BU" },
    { title: "Wines & Spirits", year: 2007, link: "https://music.youtube.com/browse/MPREb_KOzRUibncfu" },
    { title: "The Ultimate Gift", year: 2008, link: "https://music.youtube.com/browse/MPREb_6T3mWbLjg2C" },
    { title: "Bleuphoria", year: 2011, link: "https://music.youtube.com/browse/MPREb_VK6z2xFIowd" },
    { title: "6AM (Silk Remixes (Old School + House Mixes))", year: 2011, link: "https://music.youtube.com/browse/MPREb_9zRnV9PSXmL" },
    { title: "Heroes & Gods", year: 2019, link: "https://music.youtube.com/browse/MPREb_XbIN5yqTSq1" },
    { title: "Heroes & Gods 2.0 (Reimagined)", year: 2021, link: "https://music.youtube.com/browse/MPREb_wAqV9ZOxN08" },
    { title: "Live at the Belasco", year: 2021, link: "https://music.youtube.com/browse/MPREb_uNY3F4iNl5R" },
  ]
}
