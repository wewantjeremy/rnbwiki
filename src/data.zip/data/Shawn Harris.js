export default {
  id: "Shawn Harris",
  name: "Shawn Harris",

  images: [
    "/src/images/Shawn Harris/18889d7e17ef8370ebd361077bd4773a.400x400x1.jpg",
    "/src/images/Shawn Harris/images (1).jpeg",
    "/src/images/Shawn Harris/images.jpeg",
  ],

  videoIds: [
    "nNtZlURpC4w",
  ],

  biography: [
    { text: "Shawn Harris is an R&B artist and songwriter best known for his 1991 cult-classic track, \"Soulful Moaning,\" which saw a major resurgence in popularity after it was prominently sampled on Big Sean's 2020 track \"Body Language\". He is known for his smooth, slow-jam style, Harris crafted the quintessential bedroom R&B track with \"Soulful Moaning,\" which combines evocative, sensual lyrics with deeply grooving melodies. His defining discography is compiled in the album Soulful Moaning: Reincarnated available on platforms like Apple Music and Spotify. Due to his track's lasting influence, he became widely celebrated in Midwest R&B history. His music gained a new generation of listeners through WhoSampled after catching the attention of major contemporary artists. While \"Soulful Moaning\" remains a staple of 90s slow-jam playlists, Harris's personal and legal history also heavily defines his biography. He has spent decades in the Michigan state prison system, which has been covered in a variety of local retrospectives and media discussions about his life and the legacy of his hit song.", indent: true },
  ],

  albums: [
    { title: "Soulful Moaning Reincarnated", year: 2000, link: "https://music.youtube.com/playlist?list=PLKsCWLymgwsbyxvA-lnprQdH_4B1_k8Hv" },
  ]
}
