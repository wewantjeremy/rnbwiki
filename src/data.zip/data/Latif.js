export default {
  id: "Latif",
  name: "Latif",

  images: [
    "/src/images/Latif/81iSPgEX+CL._UF350,350_QL80_.jpg",
    "/src/images/Latif/ab67616d0000b2731b320d9102045a7ebe38be8b.jpeg",
    "/src/images/Latif/latif.jpg",
    "/src/images/Latif/Latif_natty_rehearsal_5.jpg",
    "/src/images/Latif/Loveinthefirst.jpg",
  ],

  videoIds: [
    "Vf0kBy6PLlE",
    "SF8Pa0ITpTc",
    "b61zn8BhoPU",
  ],

  biography: [
    { text: "Corey Latif Williams, known professionally as Latif, is an American R&B singer and Grammy nominated songwriter. He was the winner of Teen People's Who's Next contest. He was a mentee of Teddy Pendergrass. He was once signed to Universal Motown Records.", indent: true },
    { text: "Latif was born in Philadelphia, Pennsylvania. His early passion for music came mainly from his parents, who, ironically, were not musically inclined. This passion for music developed into an interest in singing.", indent: true },
    { text: "A close friend of Latif's family, Teddy Pendergrass, served as a mentor for the young budding artist. It was this mentorship that taught Latif how to \"deliver\" songs. This relationship was nurtured by Latif being taken along with Teddy to various interviews and appearances. It was this that led to Latif being noticed by the daughter of a label executive. Which brought about his first recording contract with Sony/550.", indent: true },
    { text: "Latif was given a demo deal, which helped him hone his writing skills, and gave him knowledge about the recording process. Latif's vocals were featured in a highly popular commercial for a local bank.", indent: true },
    { text: "In 2001, the buzz from winning the competition was enough to draw the eye of Kedar Massenburg. This actually worked out well for Latif, because the \"taste of spotlight\" from the performance convinced him to tell his parents that he did not want to go back to Berklee College of Music. He wanted work on his music full-time. His mother gave him one semester to prove himself, or he had to go back to school. Massenburg became interested in Latif, and signed him to Universal Motown Records.", indent: true },
    { text: "Latif's debut album on Universal Motown was called Love in the First. Only one single, \"I Don't Wanna Hurt You\" was released. It was mainly written by Latif, with production by Ryan Leslie, Bryan-Michael Cox, Adonis Shropshire, Greg Charley, Andy C, Teddy Bishop, Mechalie Jamison, D \"French\" Spencer, and Sean Garrett.", indent: true },
    { text: "Latif is no longer signed to Universal Motown Records. He has garnered a large fanbase overseas. One song that may be attributed to his international popularity is \"U Think U Know\". He has also continued to write for other artists, such as JoJo, Cassie, The Roots, Jim Jones, Joey Bada$$, Usher, Trey Songz, Chris Brown, Faith Evans, and Musiq Soulchild to name a few. He has signed a co-publishing deal with Universal Music Publishing Group (UMPG). In 2017, he teamed with friend and fellow writer-producer Aaron Kleinstaub to form duo Lo Boii. The band is signed to London-based label AWAL. Its first single \"Floor Seats\" dropped in April 2019.", indent: true },
    { text: "The Grammy Awards are awarded annually by the National Academy of Recording Arts and Sciences of the United States. Latif has received 2 nominations.", indent: true },
  ],

  albums: [
    { title: "Love in the First", year: 2003, link: "https://music.youtube.com/browse/MPREb_mZMconR0ufU" },
    { title: "Love Is Love", year: 2010, link: "https://music.youtube.com/browse/MPREb_fdAp33Vxou9" },
    { title: "Love Life", year: 2011, link: "https://music.youtube.com/browse/MPREb_SSGjVM2gHMS" },
    { title: "Breath of Fresh Air", year: 2011, link: "https://soundcloud.com/coreylatif/sets/breath-of-fresh-air-official" },
    { title: "The Leaks", year: 2011, link: "https://soundcloud.com/latifmusic/sets/latif-the-leaks-h-u-r-l-love" },
    { title: "IV Love", year: 2013, link: "https://music.youtube.com/browse/MPREb_SzINdiDt68Q" },
    { title: "Kau Yang Istimewa", year: 2025, link: "https://music.youtube.com/browse/MPREb_VFgRno7ngcZ" },
  ]
}
