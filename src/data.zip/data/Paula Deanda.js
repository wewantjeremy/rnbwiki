export default {
  id: "Paula Deanda",
  name: "Paula Deanda",

  images: [
    "/src/images/Paula Deanda/Paula Deanda_0.jpg",
    "/src/images/Paula Deanda/Paula Deanda_14.jpg",
    "/src/images/Paula Deanda/Paula Deanda_23.jpg",
    "/src/images/Paula Deanda/Paula Deanda_31.jpg",
    "/src/images/Paula Deanda/Paula Deanda_39.jpg",
    "/src/images/Paula Deanda/Paula Deanda_46.jpg",
    "/src/images/Paula Deanda/Paula Deanda_55.jpg",
    "/src/images/Paula Deanda/Paula Deanda_56.jpg",
    "/src/images/Paula Deanda/Paula Deanda_57.jpg",
    "/src/images/Paula Deanda/Paula Deanda_58.jpg",
    "/src/images/Paula Deanda/Paula Deanda_59.jpg",
  ],

  videoIds: [
    "TojOVJel8wo",
    "8ySQ0TZFIog",
    "gt4xLdw3Jdo",
    "_cknLAYbjpg",
    "bt2o61-V6DE",
    "ZYcn478p9EM",
    "lW50NyelYms",
    "TFe-SJj1xwk",
    "Cc6wRCCjtb4",
    "BGp2KAZpXAc",
    "xP8m0IXg8-c",
    "IXQ4iiGleuA",
  ],

  biography: [
    { text: "Paula Dacia DeAnda (born November 3, 1989) is an American singer and songwriter. She is best known for the 2006 US Billboard Hot 100 top twenty single \"Walk Away (Remember Me)\". Her debut album, Paula DeAnda, was released in 2006.", indent: true },
    { text: "DeAnda was born in San Angelo, Texas, to Mexican-American parents Steven and Barbara Dienda, a restaurant general manager and a registered nurse, respectively. At age six she began taking piano lessons and was soon singing at functions around town at the recommendation of her piano teacher. She also sang the national anthem at local football games. In 2002, DeAnda's family decided to move to Corpus Christi in order to help advance her career in music since Corpus Christi had a reputation as a music hub. She attended Mary Carroll High School.", indent: true },
    { text: "DeAnda was the opening act for a concert which featured hip-hop artists, Nelly, Baby Bash and Frankie J. performing in front of twenty thousand people. Her first single, \"What Would It Take\" was serviced to local radio stations in July, received airplay from ten radio stations across the country. Her next single \"Doing Too Much\" was released in December. It was then that she got the opportunity to audition for Clive Davis who signed her with Arista Records on the spot.", indent: true },
    { text: "\"Doing Too Much\" served as the lead single to her self-titled debut album which was released in the summer of 2006, and charted in the Top50 of the Billboard Hot 100. It was later certified gold in the US in 2007. Paula DeAnda charted at No. 54 on the Billboard 200 chart. The album mainly consists of songs about love and relationships and is of the pop-R&B genre. DeAnda co-wrote four songs on the album, which features production from Happy Perez among others. She was only 16 years old at the time of the album's release. Her second single \"Walk Away (Remember Me)\" (written by Christina Milian and Ne-Yo) was her biggest hit, reaching the top twenty on the Hot 100. The single was certified gold by the RIAA, becoming her second single to do so. Follow-up singles from her debut included \"When It Was Me\" and \"Easy\", the latter featuring rapper Bow Wow. She later appeared in the MTV television film Super Sweet 16: The Movie.", indent: true },
    { text: "In 2008, DeAnda began production on next effort, initially due in 2009. A buzz single \"Stunned Out\" was released and garnered some airplay, but the set's lead single ended up being the ballad \"Roll the Credits\", which was released with a music video was planned. Clive Davis left Arista's parent company at the time, RCA Label Group in 2008 to become the chief creative officer for Sony BMG. DeAnda also parted ways with Arista to become an independent artist following his departure.", indent: true },
    { text: "After leaving Arista Records, DeAnda's sophomore album was shelved, in addition to a tentative Spanish album. However her Spanish album was leaked to Yahoo Musica, a Latin Music venue that featured her leaked singles from the sophomore album. Following this period, DeAnda began posting a series of covers on YouTube in the summer of 2010. DeAnda released a series of digital singles: \"Besos\" in 2011 which would later be covered by Jojo, \"Your Place\" in 2012 and \"Shut Up and Love Me\" in 2013.", indent: true },
    { text: "Following her digital releases in 2013, DeAnda was selected to perform the National Anthem live on television at the Canelo vs Trout fight.", indent: true },
    { text: "In 2014, DeAnda auditioned for Season 6 of NBC's singing competition, The Voice. Both Shakira and Blake Shelton turned their chairs but she opted for Blake Shelton. During the Battles, Round 1, she was defeated by fellow Team Blake teammate Sisaundra Lewis after their duet of Lady Gaga's \"Do What U Want\".", indent: true },
    { text: "After The Voice, DeAnda collaborated with the Jump Smokers on her first EP The Voice & The Beats, which was released on June 25, 2014, and featured the first single \"Horns Blow (Shimmy Shimmy)\".", indent: true },
    { text: "In February 2015, DeAnda launched a Kickstarter campaign to help fund a new album, which was achieved in a couple of weeks. In May, she announced an EP titled PDA. The project was to be preceded by the song, \"Brand New\", released on March 23, 2015.", indent: true },
    { text: "In early 2018 DeAnda was asked to sing the Star Spangled Banner once more for the televised rematch fight Canelo Álvarez vs. Gennady Golovkin II. In April 2019, DeAnda featured on a single titled \"Killin' My Vibe\" by Waseem Shark and Dub Shakes, which featured her vocals in Hindi and garnered airplay success in Southeast Asia.", indent: true },
    { text: "By October 3, 2019, DeAnda released Iddi Biddi, which paid homage to Selena and Aaliyah. The song was later followed by lyric visuals and is set to promote the revival of her PDA project. Since December 2019, Paula has been hinting for a possible musical collaboration between her and Nivea. Both singers have shown interest in working together.", indent: true },
    { text: "DeAnda has cited Christina Aguilera, Jo Dee Messina, Shania Twain, Aaliyah, Brandy, LeAnn Rimes, Mariah Carey, Whitney Houston and Selena as major musical influences.", indent: true },
  ],

  albums: [
    { title: "Paula DeAnda", year: 2006, link: "https://music.youtube.com/browse/MPREb_5lQi3zGu99R" },
  ]
}
