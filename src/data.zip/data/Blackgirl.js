export default {
  id: "Blackgirl",
  name: "Blackgirl",

  images: [
    "/src/images/Blackgirl/7a8641528c9750ccbc478eacaf924e432f5f1569.jpeg",
    "/src/images/Blackgirl/blackgirl (1).jpg",
    "/src/images/Blackgirl/blackgirl-today-3410205300-e1686918503366.jpg",
    "/src/images/Blackgirl/BlackGirl.jpg",
    "/src/images/Blackgirl/Blackgirl90'sgirl.jpg",
    "/src/images/Blackgirl/Blackgirl_promo_photo.jpg",
    "/src/images/Blackgirl/getty_10.jpg",
    "/src/images/Blackgirl/getty_12.jpg",
    "/src/images/Blackgirl/getty_13.jpg",
    "/src/images/Blackgirl/getty_14.jpg",
    "/src/images/Blackgirl/getty_15.jpg",
    "/src/images/Blackgirl/getty_16.jpg",
    "/src/images/Blackgirl/getty_17.jpg",
    "/src/images/Blackgirl/getty_18.jpg",
    "/src/images/Blackgirl/getty_8.jpg",
    "/src/images/Blackgirl/getty_9.jpg",
  ],

  videoIds: [
    "IZkKgeqCgQQ",
    "Yk5qJDFpS9Q",
  ],

  biography: [
    { text: "BlackGirl is an American pop / dance vocal trio consisting of Pam Copeland, Nycolia \"Tye-V\" Turman, and Rochelle Stuart from Atlanta, that formed in 1992 on the Kaper/ RCA / BMG label. The group was frequently praised for distinguishing itself from contemporaneous girl groups such as En Vogue and SWV.", indent: true },
    { text: "During their brief career, the group released one studio album and seven singles, five of which reached the top 40 of the US Billboard charts. Their singles charted on multiple U.S. charts, including Pop, Dance, R&B, and Rap.", indent: true },
    { text: "Their most successful song, “90’s Girl,” also achieved international success, reaching the UK Top 10 and the European Hot 100 chart. Music Week praised the single as \"simply enormous\", stating that it was destined to elevate the group to SWV status. RPM magazine praised the record, calling \"90's Girl\" a \"storming R&B/pop track\" with an \"extraordinary chorus\" and \"amazing harmonies\", and stating that it would help pave the way for future R&B/pop acts. The song has since been described as an anthem of Black British womanhood—particularly for dark-skinned Black British women—reflecting themes of autonomy, creativity, authenticity, and expanded cultural representation, it was also praised for its messages of self-respect, self-reliance, and sexual autonomy. It has been ranked among the ten greatest female empowerment songs of all time.", indent: true },
    { text: "At the peak of their success, their music videos received heavy rotation on BET, MTV and The Box, helping establish a strong presence on R&B and crossover radio formats. Despite global chart success and a debut album that generated four hit singles, the group did not release a subsequent album, an outcome often noted in discussions of 1990s R&B.", indent: true },
    { text: "Although the group disbanded in 1996, BlackGirl received three Billboard nominations and two Soul Train Music Award nominations. The group was inducted into the Georgia Music Hall of Fame and received the Gregory Award for Performance within two years of the release of their debut album. The Georgia Music Hall of Fame later described BlackGirl as a legendary R&B and blues act.", indent: true },
    { text: "BlackGirl released their debut single \"Krazy\" in 1993, which was one of four consecutive top forty singles on the Billboard chart, \"Krazy\" (No. 37), \"90's Girl\" (No. 13), \"Where Did We Go Wrong\" (No. 39) and \"Let's Do It Again\" (No. 25). Their debut album, Treat U Right, was released in 1994 to positive reviews; it debuted within the top 20 of the Billboard charts. Warren Marshall of the Columbus Times remarked: \"Blackgirl -- the ultimate definition of today's `90's girls.\" Singles “Krazy” and “90's Girl” ranked among Radio & Records ’ top-performing songs of 1994. “Where Did We Go Wrong” placed at No. 9 on Adweek’s Best Singles of 1994 list and became the most-added song at radio following its release.", indent: true },
    { text: "The song also received praise from Network magazine, which described it as the ballad that would break the band, while Cashbox named it a “track to watch” on the charts. Hits compared it to Karyn White’s “Superwoman,” suggesting it could achieve similar success. “Let’s Do It Again” debuted at No. 30 on the Urban radio chart, becoming the most-added song at radio in its first week and the group’s second-biggest R&B hit. By the time “90’s Girl” was released, the album had sold over 500,000 copies in the United States and nearly three million copies worldwide, including both singles and albums.", indent: true },
    { text: "\"I wanted all of us to have the same look. When you have short hair it puts you out there\"", indent: true },
    { text: "— Pam Copeland, Vibe magazine", indent: true },
    { text: "By the end of 1994, BlackGirl had completed a six-week tour of the United States with R. Kelly, appeared on Soul Train, and appeared in a Chrysler television commercial. The group also released the holiday single “Give Love On Christmas Day”/“Christmas Time.”", indent: true },
    { text: "During this period, BlackGirl collaborated with Aaliyah, En Vogue, Mary J. Blige, Vanessa Williams, For Real, and SWV on the single “Freedom,” recorded for the soundtrack to the film Panther. The song became the group’s fifth Top 40 hit, peaking at No. 18.", indent: true },
    { text: "The remainder of the year was marked by several high-profile award-show appearances. These included a performance of their hit single “Where Did We Go Wrong” at the UNCF ’s An Evening of Stars awards ceremony, as well as appearances at the Soul Train Music Awards and the Lady of Soul Awards. The group also performed at the Georgia Hall of Fame gala, where BlackGirl received the Georgy Award for performance and was inducted into the Georgia Hall of Fame. The group also headlined a concert at Eliza Howell Park that drew more than 55,000 attendees, participated in a USO tour throughout the Far East and Europe and headlined shows with War and Patra.", indent: true },
    { text: "As 1995 approached, BlackGirl received two Soul Train Award nominations: Single of the Year (By a Group, Band or Duo) for \"Let’s Do It Again\" and Album of the Year (By a Group, Band or Duo) for Treat U Right. The group subsequently released \"90's Girl\" in the UK, where it became a top-ten hit. The single’s success was further bolstered by a performance on Top of the Pops, helping to establish BlackGirl’s popularity in the UK.", indent: true },
    { text: "Later in 1995, the group embarked on a sold-out UK tour, supported by Eric Gable and Terri & Monica. That same year, BlackGirl appeared on the single \"Hey, Look Away\" by Questionmark Asylum. The song became the group’s final charting single, reaching No. 9 on the Billboard rap chart and also finding success on the Billboard R&B chart.", indent: true },
    { text: "Toward the end of the year, BlackGirl performed alongside Chuck Berry at the Apollo Theater Hall of Fame ceremony and attended the ASCAP Awards. Despite the group’s continued success, during the early recording sessions for their second album—which was ultimately never released—Rochelle chose to step away in order to focus on her spiritual life, leading to the group's quiet disbandment in 1996.", indent: true },
    { text: "Despite the group’s absence from the music industry, their legacy continued to be recognized. In 2006, BlackGirl was featured in Essence magazine’s list of the 50 Most Inspiring African Americans. Their debut single, \"Krazy,\" was ranked No. 35 on the list of the Best Songs of 1994.", indent: true },
    { text: "Following the group’s disbandment, the members pursued individual projects. In 2010, Rochelle Stuart released a gospel album titled I Choose Jesus, under the name Rochelle Morgan.", indent: true },
    { text: "Nycolia \"Tye-V\" Turman achieved success as a songwriter, contributing to hit records for Destiny's Child, Brandy, and Blaque. In 2023, she received a nomination for a Soul Train Music Award (Ashford & Simpson Songwriter's Award) for co-writing the Billboard number-one single \"Sittin' on Top of the World\" by Burna Boy and 21 Savage.", indent: true },
    { text: "Pam Copeland went on to work with artists including Toni Braxton, Jermaine Dupri, and Johnny Gill.", indent: true },
    { text: "On January 7, 1995 BlackGirl took part in'The Lou Rawls Parade of Stars' to benefit the United Negro College Fund. In March 1995 BlackGirl joined Naomi Campbell, Coolio, Aaliyah and Naughty by Nature as part of CounterAID, a benefit for AIDS. The program raised over $200,000.", indent: true },
  ],

  albums: [
    { title: "Treat U Right", year: 1994, link: "https://music.youtube.com/playlist?list=PLKD5h9btUEzohpoazuRmAvYp6b8xB-9gP" },
  ]
}
