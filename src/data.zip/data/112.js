export default {
  id: "112",
  name: "112",

  images: [
    "/src/images/112/112_-1.jpeg",
    "/src/images/112/112_4.jpg",
    "/src/images/112/112_1.jpeg",
    "/src/images/112/112_6.jpg",
    "/src/images/112/112_5.jpg",
  ],

  videoIds: ['8dtzMPApA4M',
    "ynMnPGmhsG0",
    'GVOqbskGeBs',
    'wl2NCXzg1FQ',
    'IihCzGUEPbs',
    'xM5g3tliVU0',
    'XfiXby489Rk'],

  biography: [
    { text: "112 (pronounced \"one-twelve\") is an American R&B group from Atlanta, Georgia. Discovered by record production duo Tim & Bob, the group signed with Sean Combs's Bad Boy Records, an imprint of Arista Records to release their eponymous debut studio album (1996). The following year, they guest performed alongside labelmate Faith Evans on Sean Combs’ 1997 single \"I'll Be Missing You,\" which won a Grammy Award for Best Rap Performance by a Duo or Group and became the first hip hop song to debut atop the Billboard Hot 100. Their second and third albums, Room 112 (1998) and Part III (2001), followed thereafter; the latter peaked at number two on the Billboard 200. The group's fourth album, Hot & Wet (2003), served as their final release with Bad Boy until signing with Def Soul to release their fifth album Pleasure & Pain (2005), which saw continued commercial success. The albums spawned the Billboard Hot 100-top 20 singles \"Only You\" (featuring the Notorious B.I.G. ), \"Cupid,\" \"Anywhere\" (featuring Lil' Zane ), \"Love Me\" (featuring Mase ), \"It's Over Now,\" and the Grammy-nominated \"Peaches & Cream.\"",
      indent: true
    },
    { text: "The group had its start when the members met while attending high school. The original group, consisting of Daron Jones, Michael Keith and Reginald Finley, sang together while Jones and Keith were in middle school and Finley was in high school. Once all three were in high school, they met fellow schoolmate Aldon Lagon, who was working at a local McDonald's in Atlanta, and they added him due to his deep bass voice. They met a high tenor vocalist, Marvin Scandrick, who sang with them in the school chorus. Known as Forte, the group performed talent shows and performed at churches and schools around Atlanta. Not long after, hitmakers Tim & Bob heard of the group and sought them out. They started developing them from their living room to the studio in hopes of the duo producers first signing to Rowdy Records run by their then boss Dallas Austin. Also Kevin Wales was able to secure an audition for the group outside of Atlanta's Club 112 in Buckhead; they sang for Combs and impressed him. Following another audition for Combs in front of Bad Boy producer Chucky Thompson, Bad Boy Records artist Faith Evans and Combs' protégé Usher, and a co-sign from Thompson and Evans, Combs signed the quartet of Michael Keith, Marvin Scandrick, Daron Jones, and Quinnes Parker to Bad Boy Records. The group then changed their name from Forte to 112, the name of the nightclub where they had auditioned for Combs.",
      indent: true
    },
    { text: "Soon afterwards, they found themselves living in New York City, recording their debut album, 112. Released in 1996, the album eventually went double platinum. The album, which was primarily produced by Tim & Bob, entered into the top 5 on Billboard's Top R&B/Hip-Hop Albums Chart, going on to sell over two million copies. It featured the hit singles \"Only You\" and \"Cupid\", both of which peaked at number 13 on the Billboard Hot 100 and numbers 3 and 2 on the R&B charts, respectively. The group also contributed to records by several high-profile artists, including The Notorious B.I.G., Sean Combs (as Puff Daddy) and Mase. The group eventually went on the road as the opening act for the Isley Brothers at Ron Isley's request, the first of four separate tours that saw the group criss-crossing the U.S. with Keith Sweat, New Edition, and finally Puff Daddy and the Family, over an 18-month period. In the years that followed, they toured with other performers such as Whitney Houston and Janet Jackson. A series of single tracks by 112 populated the charts in 1997, beginning with the Tim & Bob–produced single \"Come See Me\", which hit the top 40 in January. \"Cupid\", produced by Arnold Hennings, released in May, made the top 10 and was certified gold in the same month. By August, \"Cupid\" went platinum. Another 1997 single, \"I'll Be Missing You\", hit the top 40 in June and was certified triple platinum by July. Attaining the number-one chart position by August, the song won a Grammy Award for Best Rap Performance by a Duo or Group in 1997. \"I'll Be Missing You\" sat at the top of the Billboard Hot 100 for eleven weeks and spent nine weeks at the top of the Hot Singles sales. The track also topped the R&B singles, R&B singles sales, and rap singles charts for eight weeks running.",  
      indent: true
    },
    {
      text: "The group booked tours with the Isley Brothers, Keith Sweat, and New Edition, as well as with Puff Daddy and the Family, totaling four separate tours. The group spent 18 successive months on the road fulfilling tour commitments. Their second album, Room 112, was released in 1998 and featured the hits \"Love Me\", featuring Mase, and \"Anywhere\", featuring Lil Zane. Both the album and the song \"Love Me\" were certified gold. Album sales surpassed the platinum level by January 1999, and double platinum sales were recorded in 2002. To continue supporting the album further, 112 went on tour with singer Whitney Houston for her U.S. My Love Is Your Love World Tour in the summer of 1999.",
    indent: true
    },
    { text: "A 2001 single, \"It's Over Now\", charted at the top of the Hot R&B/Hip Hop Songs. The group's third album, Part III, was released in 2001, spun the hit \"\", and earned the group their first and only Grammy nomination in the Best R&B Group or Duo category. While the group was in production on a new album for 2001, however, executive producer Combs was called to court repeatedly regarding a shooting incident. Instead of taping at the usual accommodations in Combs's studio, 112 went to Nashville, Tennessee, to record the new disc. It was a move that signaled a pending split with Bad Boy Records. The album, Part III, was released on March 20, 2001, following an intensive barrage of advance radio publicity. Even in the absence of Combs, Part III debuted at number 2 on the Billboard 200 chart. Surpassing gold sales in April, the album went platinum in May. To promote the album further, 112 joined Janet Jackson that summer for her U.S. All for You Tour. The upbeat single \"Peaches & Cream\"—which was credited in part to Combs—scored another crossover hit for the band. Released in June, the track soared to number 1 on the Rhythmic Top 40 and peaked at number 4 on the Billboard Hot 100. The group earned two award nominations for the song that year: an MTV Best Video nomination in September, and a Grammy nomination for Best R&B Performance by a Duo or Group.",
      indent: true
    },
    { text: "In 2002, the group members, having matured both personally and professionally, came to the realization that a split with the Bad Boy label was necessary due to the lack of interest. In search of greater creative control, 112 left Bad Boy Records in February 2002 and signed with Def Jam in July on their Def Soul imprint, insisting that the breakup was amicable. They reiterated this no-hard-feelings attitude by going to Diddy's House to record their first album for Def Jam. Disagreements remained over ownership rights to the 112 catalog of songs, and their fourth album Hot & Wet, the Def Jam debut disc, was waylaid as a result, while negotiations ensued between Lyor Cohen of Def Jam and Bad Boy owner Combs. With both sides ultimately in agreement, Hot & Wet appeared in November 2003, with its title song breaking into Billboard's Hot 100 and the Rhythmic Top 40 that year. In 2004, the album charted on the Billboard 200 and peaked at number 4 on the Top R&B/Hip-Hop Albums. The album, however, failed to make any noticeable impression on the charts. From the album, they released \"Na, Na, Na\", featuring dancehall legend Super Cat.",
      indent: true
    },
    { text: "Pleasure & Pain, the group's fifth album, was released in 2005, eventually reaching platinum status and featuring the popular single \"U Already Know\". The album is their first to come with a parental advisory sticker, reportedly caused by a rap from Three 6 Mafia, though a few songs on the album also contain profanity. Shortly after the release of the album, though, and amidst rumors of issues regarding money, the members separated to pursue solo careers and were subsequently dropped by Def Jam.",
      indent: true
    },
    { text: "In 2007, 112 formed their own label, One Twelve Music Group, and were in talks with a joint venture deal with Irv Gotti's The Inc. Records imprint to release an album in 2008, though this ultimately did not happen. The group continued to tour nationally and worldwide whilst they embarked on their own solo projects. Daron Jones was reported to have left the group to pursue a solo career in 2007. However, in 2008, he was seen performing with the group again while overseas in Germany and Belgium. Slim is featured along with Three 6 Mafia on 8Ball & MJG's second single \"Cruzin'\" off of their album Ridin High.",
      indent: true
    },
    { text: "Slim signed his a joint venture deal with Asylum/Atlantic with his M3 Productions Inc. and released his solo debut album Love's Crazy in November 2008. His first single was \"So Fly\", featuring Yung Joc and Shawty Lo. In an interview with MiddleChildPromotions, Q. Parker confirmed that his debut album would be titled Real Talk and was due for release in September 2008. The album was later scheduled for release in 2009, however, the album never got released. He was in the studio working with Tim & Bob, The Pirates, Jammy, Bryan-Michael Cox, The Platinum Brothers and Crystal Johnson. The album was released under a joint venture between his own label, NewFam Entertainment, and Drift City Records. The first single off the album is called \"Crazy Crazy\" and it features Rock City.",
      indent: true 
    },
    {
      text: "Slim decided to leave 112 and go solo. He stated that a former groupmate stole his, and member Mike's, money, causing the two to leave. Mike, however, states that he never fell out with anyone over money and is still with 112. The group now consists of members Q, Slim and Daron. Mike said his business partner showed him that he was not receiving his royalty checks. Mike released his debut solo album, Michael Keith, on September 30, 2008, as a digital download through iTunes and Amazon MP3. He also released two songs, \"She's My Superstar\" and \"Sexy\", under the pseudonym \"Dangerus\" via the internet. In 2010, Michael Keith reconciled with the other three members of 112 and signaled his intention to record with the group on their sixth studio album.",
      indent: true
    },
    {
      text: "In March 2010, it was announced via Q. Parker that 112 had returned to the studio and was recording new material. He broke the news via Twitter: \"In the studio with my boys Mike and Daron! New 112 album comin soon!\" The news of the group's reunion was also confirmed by member Daron Jones in an interview published on Sound-Savvy.com. Jones confirmed that the reunion would include Mike and Q, and possibly Slim. He commented, \"Slim just didn't want to be a part of it\", but there were rumors that Slim might have had a change of heart, as he had recently recorded a song with the group called \"One More Try\"; however, Slim would go on to collaborate on the album, although it would not be released until 2017.",
      indent: true
    },
    {
      text: "In January 2011, Q. Parker released a 12-month fitness calendar and announced that his solo project will be released sometime that year. In March 2012, Daron confirmed that all four members of the group were reconciled and had got back together for a tour titled For The Fans Tour, which kicked off in mid-2012. On July 24, 2020, 112 released the single \"Spend It All\". In an interview with Rated R&B, they described the song as \"an ode to women.\" \"Spend It All\" is the first single from 112's EP Forever, which they independently released on September 4. The band, as 2 members, embarked on the \"Room 112 Tour\" from November 2025 to February 2026 for the 30th anniversary of the group.",
      indent: true
    }
    ],

  albums: [
    { title: "112", year: 1996, link: "https://music.youtube.com/playlist?list=OLAK5uy_mOYTi65Igi0slL38hfEZCSoUkPlETw4ew" },
    { title: "Room 112", year: 1998, link: "https://music.youtube.com/playlist?list=OLAK5uy_lHO6reqKQ0BFrLtx81wMU8WYkkyNK9LyE" },
    { title: "Part III", year: 2001, link: "https://music.youtube.com/playlist?list=OLAK5uy_nsB1J22-FnzLR0y7z3np_Ze01cgXFvYjQ" },
    { title: "Hot & Wet", year: 2003, link: "https://music.youtube.com/playlist?list=OLAK5uy_k9zwA0BD2XgUi6849kKZT0YPB8Gx7vqFI" },
    { title: "Pleasure & Pain", year: 2005, link: "https://music.youtube.com/playlist?list=OLAK5uy_lUmR-8lArKqdvxIx2xXXnLYTzgi0aI_Mo" },
    { title: "Q, Mike, Slim, Daron", year: 2017, link: "https://music.youtube.com/playlist?list=OLAK5uy_n0xskHN6l_bS56EG0OFg5Ex2BETFETe2Y" },
    { title: "Forever", year: 2020, link: "https://music.youtube.com/playlist?list=OLAK5uy_mlEUAXzmvvdObHRly17D9v6TpJPPkB4pA" },
  ]
}