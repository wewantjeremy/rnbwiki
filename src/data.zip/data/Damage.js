export default {
  id: "Damage",
  name: "Damage",

  images: [
    "/src/images/Damage/damage.jpg",
    "/src/images/Damage/Ghetto_Romance_Damage_cover.png",
    "/src/images/Damage/images (2).jpeg",
    "/src/images/Damage/Love_Guaranteed_Damage_CD1_cover.png",
    "/src/images/Damage/unnamed (1).jpg",
  ],

  videoIds: [
    "RMG5yX77QIw",
    "aQd76nmsn8A",
    "tnQgc_KcYO4",
    "9ZoERIO1Ejw",
    "AsgFM7j9h0w",
    "dJsYT4RpHcg",
  ],

  biography: [
    { text: "Damage are a British R&B act who achieved success in the 1990s with eleven hit singles, including four top 10 successes on the UK Singles Chart. They have sold 4 million records worldwide. The band consists of Jade Jones, Rahsaan J Bromfield, Andrez Harriott, and Noel Simpson.", indent: true },
    { text: "The band was formed by Rahsaan \"Ras\" Bromfield and Noel Simpson who were students at the Barbara Speake Stage School in the London neighbourhood of Acton. They rapped and danced at school assemblies. Jade Jones was brought into the band when Bromfield and Simpson heard him sing a high note. Andrez Harriott, a student at Sylvia Young Theatre School, was recruited after he and Jones performed together in the musical play Carmen Jones. Coreé Richards was asked to join the band after he was heard singing at a bus stop. The band sent a demo tape of a cover version of the Jackson 5 song \"Anything\" to Jazz Summers of Big Life Records in early 1995. Damage made inroads into the UK Singles Chart and the second single \"Love II Love\" reached number 12 while the follow-up, \"Forever\", charted at number 6 during the Christmas period. \"Forever\" was also notable for being both the first song that Steve Mac and Wayne Hector wrote together, and the song that caught the ear of Simon Cowell and effectively led to Mac becoming the chief songwriter-producer for Cowell's subsequent projects.", indent: true },
    { text: "Damage's debut album Forever followed in 1997, along with two further UK top 10 singles – \"Love Guaranteed\" and a cover version of Eric Clapton's \"Wonderful Tonight\", the latter reaching number 3. The quintet subsequently embarked on an extensive touring schedule while negotiating a new recording contract following the collapse of Big Life. Jones remained in the media spotlight through his long-term romance with Emma Bunton of the Spice Girls.", indent: true },
    { text: "In 2000, the band signed with Cooltempo Records and released the first single from their second album, \"Ghetto Romance\". The song was produced by production duo Tim & Bob, and peaked at No. 7 on the UK Singles Chart. On 30 August, \"Rumours\" was released as second single. The song is a mixture of R&B and 2-step. The CD2 single contains UK garage remixes of \"Rumours\" and their previous single \"Ghetto Romance\", as remixed by Ed Case & Carl H and Groove Chronicles, respectively. The second album was initially due for release on 25 September 2000, following the release of \"Rumours\". However, the release date was subsequently pushed back to allow for new material to be recorded. This resulted in the album's track listing being revised. The initial track listing includes the tracks \"Feelin' Me\" and \"Midnight Caller\", as well as an outro called \"Before We Leave\".", indent: true },
    { text: "The second album, Since You've Been Gone, was released on 2 April 2001. However, the final release omits the last tracks and instead replaces them with \"I Don't Know\" (featuring Emma Bunton), \"After the Love Has Gone\" and a Mushtaq mix of \"So What If I\". \"After the Love Has Gone\" was released as the fifth and final single from the album in December 2001.", indent: true },
    { text: "A short while later, after being dropped by their record label, the band decided to become independent artists, setting up their own management company, Set It Off Management. In April 2002, the band supported Gabrielle on her UK Arena Tour, where they premiered new material for the first time. In an attempt to re-invent themselves, the band decided to become a musical ensemble, with Andrez moving to drums, Noel to keyboards and Rahsaan to lead guitar, retaining Jade and Coree on lead vocals. An EP of tracks recorded on the tour, entitled \"Live and Liberated\", was made available for a short time. The tracklisting includes the previously unreleased tracks \"Scum\", \"Boogie Woogie\", \"That's It\", \"So Ridiculous\" and \"Diamonds & Roses\", the intended lead single from a third album that the band were recording at the time. The group claimed that the EP was the first time they had recorded music \"we truly wanted to make\".", indent: true },
    { text: "Shortly after the tour, after much tension in the Damage camp, and a bust up with Jones, Richards decided to leave the band. Although the remaining four members decided to continue, less than six months later, the band had split. Harriott and Jones formed CherryBlackStone, a six-piece ensemble, which also included Harriott's wife Wendy. After releasing an EP in 2006, and supporting Beverley Knight on her UK Arena Tour in 2007, the band subsequently split. In 2010, the original line-up reformed for a one-off gig at Party in the Park in Leeds on 25 July, but did not officially reunite at that time.", indent: true },
    { text: "In 2012, Damage reformed as a quartet without Richards and began performing a series of club gigs. In late 2013, it was announced that Damage would appear in the second series of the ITV2 documentary The Big Reunion along with other groups such as Eternal and A1. Richards did appear on the show to talk about the band and meet with his bandmates one last time. Since their reformation the group have sporadically performed at gigs together.", indent: true },
  ],

  albums: [
    { title: "Forever", year: 1997, link: "https://music.youtube.com/playlist?list=OLAK5uy_kv8_8jsFWehwiYItY376ZL1rx6pUdXhAw" },
    { title: "Since U Been Gone", year: 2001, link: "https://music.youtube.com/playlist?list=OLAK5uy_kZZydsvNibkNxbjF4EKYBvqFHvieb26ss" },
    { title: "B-Sides", year: 2019, link: "https://music.youtube.com/playlist?list=OLAK5uy_mrcQPr5vRVLR_yKuDN_hWtnFm3x4igWOg" },
  ]
}
