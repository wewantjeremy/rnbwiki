export default {
  id: "Millie Scott",
  name: "Millie Scott",

  images: [
    "/src/images/Millie Scott/A-64135-1249408082.jpg",
    "/src/images/Millie Scott/images (1).jpeg",
    "/src/images/Millie Scott/images.jpeg",
    "/src/images/Millie Scott/millie-scott.jpg",
    "/src/images/Millie Scott/R-4358669-1362754156-8518.jpg",
  ],

  videoIds: [
    "aF-edl3Mehc",
    "QLbi7SjqoPg",
    "b3t44lrydSA",
    "37zp0Iaq6YQ",
  ],

  biography: [
    { text: "Millie Scott (born Mildred Vaney Scott on March 4, 1947 in Savannah, Georgia) is an R&B music singer from the ’80s.", indent: true },
    { text: "Millie began her career by singing in gospel music groups such as the Pilgrim Gospel Singers and the Sermonettes before switching to jazz music. She also performed with Bobby Dilworth and the Blazers. She later moved to New York where she worked as a session singer.", indent: true },
    { text: "When R&B group, the Temptations visited New York, they encouraged Millie to move to Detroit, Michigan. In 1971, she formed a music group called Quiet Essence, toured as a back-up vocalist for Al Green and formed another music group called Cut Glass, whom she worked with for three years. In 1986, she was signed to D&B Productions in Detroit, Michigan and later signed a record deal with Island Records and released her debut single, “Automatic” which peaked at #56 on the U.K. Singles chart and #49 on Billboard’s Hot Black Singles chart, staying on the chart for 10 weeks.", indent: true },
    { text: "Her follow-up single, “Prisoner of Love” peaked at #52 on the U.K. Singles chart and #13 on Billboard’s Hot Dance/Disco Club Play chart, staying on the chart for 10 weeks. It also peaked at #43 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart and #78 on Billboard’s Hot Black Singles chart, staying on the chart for 4 weeks. In 1987, Millie released her debut studio album, “Love Me Right” on the 4th & Broadway record label which peaked at #57 on Billboard’s R&B Albums chart. The third single from the album, “Ev’ry Little Bit” peaked at #63 on the U.K. Singles chart, #30 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart and #11 on Billboard’s Hot Black Singles chart, staying on the chart for 15 weeks. The title song managed to peak at #40 on Billboard’s Hot Black Singles chart, staying on the chart for 11 weeks. In 1988, Millie released her sophomore and last studio album to date, “I Can Make It Good For You” which didn’t chart. The first two singles released from the album: “It’s My Life” (which peaked at #90) and “A Love of Your Own” (which peaked at #66) managed to make Billboard’s Hot Black Singles chart; however, the last single, “To the Letter” failed to make the charts.", indent: true },
    { text: "Afterwards, it seems as if Millie has faded into obscurity. Not much has been heard from her since the ’80s and it’s currently unknown what she’s up to.", indent: true },
  ],

  albums: [
    { title: "Love Me Right", year: 1987, link: "https://music.youtube.com/browse/MPREb_hghUY6DBKlK" },
    { title: "I Can Make It Good For You", year: 1988, link: "https://music.youtube.com/playlist?list=PLdGec_eTWK4A" },
  ]
}
