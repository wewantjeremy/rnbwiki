export default {
  id: "3T",
  name: "3T",

  images: [
    "/src/images/3T/3T_1.jpg",
    "/src/images/3T/3T_3.jpg",
    "/src/images/3T/3T_4.jpg",
    "/src/images/3T/3T_8.jpg",
    "/src/images/3T/3T_in_performance_(Hannover,_1996).jpg",
    "/src/images/3T/60cb25779c7469484bc3e12c70737970.1000x1000x1.jpg",
    "/src/images/3T/Screenshot 2026-06-30 at 6.19.30 PM.png",
  ],

  videoIds: [
    "EBoX-wYhs-U",
    "86Hyjx5U8Ns",
    "D86ye9nCBLM",
    "p6aJBGM3t1Y",
    "FFWMk24CEB8",
    "fBdvxVs1E04",
    "IxrnPd7UzM0",
  ],

  biography: [
    { text: "3T is an American R&B / pop music trio featuring the three sons of Tito Jackson of the Jackson 5 and Delores \"Dee Dee\" Jackson. The band members include Tariano Adaryll Jackson II (\"Taj\") (born August 4, 1973), Taryll Adren Jackson (born August 8, 1975) and Tito Joe Jackson (\"T.J.\") (born July 16, 1978). Their late uncle Michael Jackson mentored the trio, and signed them to his label MJJ Music.", indent: true },
    { text: "3T released their debut album Brotherhood in 1995. The album sold approximately three million copies worldwide. The group achieved an international hit with their debut single \"Anything\". 3T released several hit singles in Europe, including \"24/7\", \"Why\" (a duet with Michael Jackson), \"I Need You\" (featuring a brief appearance by Michael), \"Tease Me\" and \"Gotta Be You\". In 1996, they were ranked second behind the Spice Girls as the biggest-selling group in Europe. 3T has also written and produced songs for soundtracks for film. Their work was featured in The Jacksons: An American Dream, Free Willy, Free Willy 2: The Adventure Home, Men in Black and Trippin'. In early 1997, they went on a hugely successful European tour performing their debut album, which included all of the songs from the album, as well as a Jackson 5 tribute (featuring Tito Jackson), and a surprise performance of the Oasis hit \"Wonderwall\".", indent: true },
    { text: "3T completed an album after the release of Brotherhood, with over 20 songs being recorded and 12 planned to be included on the final tracklist. The album was never released by Sony due to a strained relationship between Sony and Michael Jackson, and is referred by many fans as The Lost Album.", indent: true },
    { text: "Taryll and T.J. have written and produced tracks for their aunt Janet Jackson as well as for Lindsay Lohan and Bruno Mars. After signing with the French label TF1/NRJ in 2003, 3T continued to perform in France, the Netherlands and Belgium. The group signed with the Dutch label Digidance in 2004 for Dutch releases, appearances, and performances. The album, titled Identity, was released on March 23, 2004. Two singles were released: \"Stuck On You\" (a cover of the Lionel Richie song) in 2003, and \"Sex Appeal\" in 2004. Neither single was released outside of Europe.", indent: true },
    { text: "In 2008, 3T made Identity available on both iTunes and Amazon worldwide. The brothers appeared on the show This Is David Gest in 2007, also recording the theme song \"Crazy Kinda Guy\". The show first aired on April 22, 2007. They appeared in an episode where Gest took cameras to the Jackson family house in Encino, California, where he met with Tito and 3T as well as matriarch Katherine Jackson. A later episode showed them recording the theme song.", indent: true },
    { text: "During the summer of 2008, the Jackson family (including  Taj and T.J.) stayed for six weeks in Appledore, Devon, England while searching for a house to buy in the area. The project was filmed for a Channel 4 documentary called The Jacksons are Coming, which was aired in 2008. Taj and T.J. also attended a Michael Jackson fan event in Devon as part of their stay.", indent: true },
    { text: "3T appeared on the A&E TV show entitled The Jacksons: A Family Dynasty. They appear with their father Tito, who tries to convince them to relaunch 3T.", indent: true },
    { text: "On January 31, 2010, 3T appeared on stage at the 52nd Grammy Awards to support their cousins Prince Michael Jr. and Paris Michael Katherine Jackson as they accepted the Lifetime Achievement Award on behalf of their father, Michael Jackson. On February 1, 2010, the group appeared a remake of \"We Are the World\", in aid of the Haiti Appeal. Currently, Taj is working on the Code Z zombie series and a science fiction project called Clone 3. T.J. was selected to play the role of Prince Jean-Luc in the new stage version of Larry Hart's musical Sisterella that was scheduled to premiere in the fall of 2011. Taryll is working on his first solo album that he hopes will make his family and fans proud.", indent: true },
  ],

  albums: [
    { title: "Brotherhood", year: 1995, link: "https://music.youtube.com/browse/MPREb_8qMMF9kFrtg" },
    { title: "Identity", year: 2004, link: "https://music.youtube.com/browse/MPREb_pI4UxmaflIK" },
    { title: "Chapter III", year: 2015, link: "https://music.youtube.com/browse/MPREb_DK4XgFICCGm" },
  ]
}
