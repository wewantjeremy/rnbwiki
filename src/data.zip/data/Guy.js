export default {
  id: "Guy",
  name: "Guy",

  images: [
    "/src/images/Guy/61AH0BxDFBL._UF1000,1000_QL80_.jpg",
    "/src/images/Guy/ab67616d00001e02db3ceb24f7e71b68b8d33def.jpeg",
    "/src/images/Guy/bd249481cf5c519767fff3a165fbd4f2.jpg",
    "/src/images/Guy/Guy-2014.jpg",
    "/src/images/Guy/GuyIIIAlbum.jpg",
    "/src/images/Guy/MV5BZTE3Mzk2NGEtY2NkZC00YzVlLWJjOGYtZjQ5ZjY5Mzc4MjAyXkEyXkFqcGc@._V1_.jpg",
    "/src/images/Guy/Screenshot 2026-07-01 at 7.03.06 PM.png",
    "/src/images/Guy/Screenshot 2026-07-01 at 7.03.21 PM.png",
    "/src/images/Guy/Screenshot 2026-07-01 at 7.03.31 PM.png",
  ],

  videoIds: [
    "PAu2bsV9CiQ",
    "3Wj8Yxa309E",
    "WR4b4V-lH1I",
    "oxTXjnig4BA",
    "JdFceqWv2OI",
    "EOG-K7ASCvA",
    "JHEF4p8cErY",
    "pnH0HGhQgyU",
    "QaVzZ0-Csh8",
  ],

  biography: [
    { text: "Guy is an American R&B group founded in 1987 by Teddy Riley, Aaron Hall, and Timmy Gatling. Hall's younger brother Damion Hall replaced Gatling after the recording of the group's self-titled debut album. The group released their debut album, which went on to sell over a million copies and was certified double platinum. Following their success, the group released their second album The Future in 1990, which also charted with successful singles and received platinum as well. Following their nearly decade long split, the group returned with their third album before the 2000s, which charted with their hit single \"Dancin'\".", indent: true },
    { text: "Guy held the credit as the pioneer of the new jack swing genre with the early interactions of their work, which was developed and mainstreamed by Riley.", indent: true },
    { text: "Teddy Riley and Timmy Gatling both grew up in the Harlem section of New York City. Both of their family households were musically active and took inspiration from late 70s acts such as the Gap Band, Earth Wind & Fire and the Jacksons. They soon got involved in local live bands for ages around 12 to 20. Riley was in a band called The Climates as a 12-year-old prodigy piano player.", indent: true },
    { text: "At the time, music executive Gene Griffin was scouting for young artists and owned a label called Sounds of New York, which had artists such as Indeep (known for the \"Last Night a D.J. Saved My Life\" hit single). Griffin offered Teddy Riley a contract to form the kid group Kids at Work. Sony Music Publishing handled distribution. The band consisted of Teddy Riley playing on keyboard, Timmy Gatling on vocals and bass, and Clurel Henderson on percussion & lead vocals.", indent: true },
    { text: "In 1984, they released their self-titled debut album. [citation needed] The group eventually left the label after Griffin’s sudden incarceration. Teddy Riley would go on to produce other projects such as “ The Show ” for Doug E. Fresh.", indent: true },
    { text: "After the breakup of Kids at Work, Griffin offered Gatling a new deal to create a band. Gatling approached Aaron Hall, with whom he used to work in Abraham & Straus'shoe department. Hall sang in choirs at the Bethel Gospel Tabernacle in Jamaica, Queens. Gatling introduced Hall to Teddy Riley, and the three named their new group Guy. Gene Griffin became their manager and was credited as producer as he introduced them to Uptown Records founder Andre Harrell, who immediately signed the trio.", indent: true },
    { text: "Under the guidance of manager Gene Griffin, the trio signed to Andre Harrell's Uptown Records and released Guy in June 1988. Gatling was forced out of the group by Gene Griffin because he refused to sign the management contract, which gave Gene Griffin full control of their publishing and income. His face was kept on the album because he was officially part of the group and MCA Records needed his permission to release the album. Gatling released his solo debut, Help, in 1989 on Tommy Boy / Warner Bros. Records and wrote and produced songs such as \"Promises, Promises\" for Christopher Williams and \"When Will I See You Smile Again?\" for Bell Biv DeVoe.", indent: true },
    { text: "Five singles were released from Guy, only one of which, \"I Like,\" charted on the Billboard Hot 100. However, four of the album's singles became significant Billboard R&B chart hits: \"Groove Me\" (#4), \"Teddy's Jam\" (#5), \"I Like\" (#2), and \"Spend the Night\" (#15) helped propel the album to double platinum status. In addition, \"'Round and'Round (Merry Go'Round of Love)\" reached #24 on the R&B chart, and \"Piece of My Love\" also received some airplay on R&B stations. Guy reached #1 on the Billboard R&B album chart and, more impressively, climbed to #27 on the Billboard 200 album chart without a major pop hit.", indent: true },
    { text: "The band contributed the song \"My Fantasy\" to the soundtrack of Spike Lee's film Do the Right Thing in 1989. Riley and Gene Griffin also worked with Boy George, producing his R&B hit \"Don't Take My Mind on a Trip.\" However, that same year Guy split acrimoniously from Griffin. Riley continued to produce and remix for other artists and firmly established himself as the figurehead and driving force behind new jack swing.", indent: true },
    { text: "In November 1990 Guy released its second album, The Future. Although still not scoring Top 40 pop hits, the album's five singles became R&B hits: \"Wanna Get Wit U\" (#4); \"Let's Chill\" (#3); \"Do Me Right,\" featuring Heavy D) (#2); \"D-O-G Me Out\" (#8); and \"Let's Stay Together\" (#16) took the album to platinum status. In 1991 Guy made an appearance in Mario Van Peebles's film New Jack City, performing the song of the same name.", indent: true },
    { text: "After touring behind The Future, the group split up, later citing \"the tragedy of our ex-manager,\" Gene Griffin, as the reason for Guy's disbandment. One of their final recordings during this period was a cover of Wilson Pickett's Land of a Thousand Dances for the 1992 animated film FernGully: The Last Rainforest. Riley then focused on producing other artists, such as Heavy D and Michael Jackson, and formed a new group, Blackstreet. The two Hall brothers each pursued solo careers during the'90s.", indent: true },
    { text: "Guy has reformed periodically since their initial break-up, the first of which occurred in 1995, with the release of the song \"Tell Me What You Like\", but an album did not follow at that time.", indent: true },
    { text: "In 1999, Riley and the Hall brothers reunited to release their first album in nine years titled Guy III. The album featured the modest hit \"Dancin'\" produced by Eddie F, Darren Lighty and G-Wise, which peaked at No. 19 on the US Hot 100 chart, becoming surprisingly their biggest hit on the pop charts. However, the album was poorly promoted and as quickly as it was released it dropped from the public consciousness. The group disbanded again soon after, but reformed periodically from 2005 onwards, and despite rumours of another album, they have yet to release another.", indent: true },
    { text: "In 2006, they were part of the New Jack Reunion Tour line up, along with BLACKstreet, Tony! Toni! Toné!, After 7, New Edition, and SWV.", indent: true },
    { text: "Riley and the Hall brothers reunited at the 2009 BET Awards, performing \"I Like\" as part of a new jack swing medley.", indent: true },
    { text: "Speaking in March 2010 to noted UK R&B writer Pete Lewis – Deputy Editor of the award-winning Blues & Soul – Riley confirmed he is no longer involved with Guy. He went on to perform with the group again in October 2010. However, the reunion was short-lived following claims by other band members that Riley had not properly distributed royalties he had collected on behalf of Guy. [citation needed]", indent: true },
    { text: "On January 16, 2011, Aaron and Damion performed without Teddy at BET Honors in Washington, D.C.. \"Guy brought the audience to its feet with new-jack-swing-era hits Let's Chill and Groove Me.\" – The Washington Post. The performance at BET Honors became a trending topic on Twitter when it aired on February 21, 2011. The duo appeared again on February 17, 2011, on the TV One Black History Month special \"Way Black When.\" As of 2013, Riley has announced he's returned to Guy and will be working with Guy as well as Blackstreet. Riley's return in 2013 was short and he left once again according to Aaron Hall. In August 2014, Riley announced via his official Instagram that he has reunited with the Hall brothers with a new website and tour coming soon.", indent: true },
  ],

  albums: [
    { title: "Guy", year: 1988, link: "https://music.youtube.com/browse/MPREb_j5dT4veTeid" },
    { title: "The Future", year: 1990, link: "https://music.youtube.com/browse/MPREb_bIhT6ekD5BX" },
    { title: "III", year: 2000, link: "https://music.youtube.com/browse/MPREb_lBn27vxl9Gr" },
  ]
}
