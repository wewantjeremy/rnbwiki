export default {
  id: "KCM",
  name: "KCM",

  images: [
    "/src/images/KCM/hq720.jpg",
    "/src/images/KCM/Screenshot 2026-07-02 at 2.58.30 AM.png",
  ],

  videoIds: [
    "724U4ACwECg",
    "eDmu8sGI4o8",
  ],

  biography: [],

  albums: [
    { title: "Beautiful Mind", year: 2004, link: "https://music.youtube.com/browse/MPREb_23fN4se57mG" },
    { title: "Growing Up", year: 2005, link: "https://music.youtube.com/browse/MPREb_7cxAq0LDb5q" },
    { title: "Love Affair", year: 2006, link: "https://music.youtube.com/browse/MPREb_vaFWRRXLFYI" },
    { title: "Kingdom", year: 2008, link: "https://music.youtube.com/browse/MPREb_YL6EpE4AxTj" },
    { title: "Alone (Part. 1)", year: 2009, link: "https://music.youtube.com/browse/MPREb_jKyQMpOfXK2" },
    { title: "Assorted gems (Original Soundtrack) Part.1", year: 2009, link: "https://music.youtube.com/browse/MPREb_HkIbA1ID09W" },
    { title: "Espresso", year: 2009, link: "https://music.youtube.com/browse/MPREb_KVSj2WWyHRJ" },
    { title: "One Day", year: 2010, link: "https://music.youtube.com/browse/MPREb_nFj1vMu5toi" },
    { title: "CS Numbers Special", year: 2013, link: "https://music.youtube.com/browse/MPREb_iPIaF2hALGd" },
    { title: "CS NUMBERS, Vol.7", year: 2014, link: "https://music.youtube.com/browse/MPREb_ebuq6G2Si9I" },
    { title: "CS NUMBERS, Vol.6", year: 2014, link: "https://music.youtube.com/browse/MPREb_1IJthvLpa0I" },
    { title: "CS NUMBERS", year: 2014, link: "https://music.youtube.com/browse/MPREb_77ri6VDctU0" },
    { title: "Pretend, Thrill me.", year: 2015, link: "https://music.youtube.com/browse/MPREb_jNkYvQOFJD3" },
    { title: "REFLECTION OF MY MIND", year: 2016, link: "https://music.youtube.com/browse/MPREb_oU4GYYNxxhD" },
    { title: "Promise", year: 2019, link: "https://music.youtube.com/browse/MPREb_6yzc6fYprH4" },
    { title: "GIFT (Japanese Ver.)", year: 2024, link: "https://music.youtube.com/browse/MPREb_JxBJ3D1dNEW" },
    { title: "US (우리들)", year: 2024, link: "https://music.youtube.com/browse/MPREb_zyZY5f7Rk3D" },
  ]
}
