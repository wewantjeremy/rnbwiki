export default {
  id: "Michel'le",
  name: "Michel'le",

  images: [
    "/src/images/Michel'le/18458912.jpeg",
    "/src/images/Michel'le/7eb5eb7ed75d7fc8242a00c70e9d4438530dbe49.jpeg",
    "/src/images/Michel'le/hung-jury.jpg",
    "/src/images/Michel'le/images (1).jpeg",
    "/src/images/Michel'le/images (2).jpeg",
    "/src/images/Michel'le/images (3).jpeg",
    "/src/images/Michel'le/images (4).jpeg",
    "/src/images/Michel'le/images.jpeg",
    "/src/images/Michel'le/img_1645.jpg",
    "/src/images/Michel'le/Michel'le_2015_2_(cropped).jpg",
    "/src/images/Michel'le/Michel'le_Toussaint_(right)_(4225423453).jpg",
    "/src/images/Michel'le/michelle-twitter.jpg",
    "/src/images/Michel'le/Screenshot 2026-07-02 at 3.13.19 PM.png",
    "/src/images/Michel'le/Screenshot 2026-07-02 at 3.13.32 PM.png",
    "/src/images/Michel'le/Screenshot 2026-07-02 at 3.13.53 PM.png",
  ],

  videoIds: [
    "NWKlp0UK97M",
    "AFHYBbi99jw",
    "gC0PuCFtsdQ",
    "JIQod_tn1Qg",
    "I7Nn-KbasU8",
    "87xOPBXAZLg",
  ],

  biography: [
    { text: "Michel'le Denise Toussant (/ m ɪ ʃ ɛ l ˈ eɪ / mish-el- AY; born December 5, 1967), also spelled Toussaint, is an American R&B singer known for her songs from 1989 to the early 1990s. Her highest charting song is the top ten US Hot 100 hit \"No More Lies\". Between 2013 and 2015, Michel'le was one of six members on the TV One reality show R&B Divas: Los Angeles. She is also the subject of the 2016 biopic Surviving Compton: Dre, Suge & Michel'le.", indent: true },
    { text: "Michel'le, a native of California, was originally a featured female vocalist of World Class Wreckin' Cru's 1987 single \"Turn Off the Lights\". She was called at the last minute to record vocals for Mona Lisa, who could not make it to the studio. Michel'le was signed to Eazy-E's Ruthless Records. In 1989, her self-titled debut album was released, produced entirely by then-boyfriend, rapper Dr. Dre. The album contained the single \"No More Lies\" which peaked at No. 7 on the US Billboard Hot 100, and the hit R&B singles \"Nicety\" and \"Something in My Heart\". Michel'le was certified Gold on April 25, 1990, for sales of over 500,000 copies in the US. During the Suge Knight shakedown incident, Jerry Heller was forced to sign over Dr. Dre, The D.O.C. and Michel'le. The West Coast All-Stars, in which she had a role, scored a nomination for Best Rap Performance by a Duo or Group at the 33rd Grammy Awards for the single \"We're All in the Same Gang\" - the West Coast All-Stars also included MC Hammer, Young MC, Ice-T, JJ Fad as well as N.W.A members Dr. Dre, MC Ren, and Eazy-E.", indent: true },
    { text: "In 1998, nine years after the release of her first album, she released her second album, Hung Jury, on Death Row Records but it garnered little attention and no hit singles. As of 2013, worldwide sales for the album stood at under 100,000 copies. Michel'le also provided vocals on 2Pac's song \"Run tha Streets\" on his album All Eyez on Me, and Tha Dogg Pound's song \"Let's Play House\" on their debut Dogg Food. Soon after Dr. Dre's departure from Death Row Records in 1996, Michel'le and Dr. Dre parted ways after he became engaged to another woman.", indent: true },
    { text: "Michel'le contributed to the soundtrack Dysfunktional in 2003. She has since confirmed through several media outlets that she's been working on new material and looking for a label for her third album. In 2011 and 2014, Michel'le released new singles \"Freedom to Love\" and \"It Still Hurts\", though she hasn't released an album since 1998. A trailer video for her single \"Freedom to Love\" can be seen on YouTube.", indent: true },
    { text: "In 2013, Michel'le was part of the cast of TV One's R&B Divas LA.", indent: true },
    { text: "Her character was left out of the 2015 film Straight Outta Compton, even though she played a role in N.W.A. Michel'le was included in the notorious N.W.A diss track No Vaseline on Ice Cube's 1991 double platinum effort, Death Certificate, in a reference to a video the group made with the female singer. This omission gave her the opportunity to tell her story. On October 15, 2016, Lifetime aired a biopic about her life titled Surviving Compton: Dre, Suge & Michel'le. She was portrayed by Rhyon Nicole Brown. It tells the story of her abusive relationship with Dr. Dre and Suge Knight, her experiences with Ruthless Records, and the journey she went through to find herself. Her intentions with the biopic is to help encourage other victims of domestic violence.", indent: true },
    { text: "Michel'le was cast as herself in the stage play Love Jones: The Musical.", indent: true },
    { text: "Michel'le met Dr. Dre, whose real name is Andre Romelle Young, at 20 years old when doing a vocal part for his group known as the World Class Wreckin' Cru. The song was titled as \"Turn Off the Lights\" and was released in 1987. It later peaked at No. 54 on the Billboard Charts. They began dating a few months after meeting one another. The couple later became engaged and had their son, Marcel, in February 1991. Marcel was Michel'le's first child and Dre's sixth. After their son was born, their relationship became more strained due to Dre's drinking, infidelity and volatile behavior. Michel'le has stated that Dre was physically abusive throughout their relationship. Her injuries included a broken nose (which she had to have surgically corrected), a cracked rib and five black eyes. She recalled on The Breakfast Club that during an argument, Dre shot at Michel'le, missing her by inches. She left the bullet in the door for him to see and said, \"he never tried to shoot me anymore. Thank God. But the beatings were—it was a lot… His last wife, I just couldn't do it anymore. It's too much.\" She then began to self medicate with prescription pills and alcohol. Michel'le left Dre after she discovered that he was engaged to another woman.", indent: true },
    { text: "At her lowest point with Dre, Death Row Records CEO/co-founder Suge Knight stepped in to help get Michel'le clean by sending her to rehab. In 1999, Michel'le married Suge while he was in prison. She filed for divorce six years later. Michel'le discovered that her marriage to Suge was invalid through the divorce process because he was still married to his ex-wife Sharitha. Michel'le stated Suge hit her once, dislocating her jaw. They have a daughter, Bailei (b. 2002). In 2009, Michel'le went to court over unpaid spousal and child support from Suge.", indent: true },
    { text: "In 2015, after Dre was criticized for omitting his past of abusing women in the film Straight Outta Compton, he issued a statement to The New York Times apologizing to the women he has hurt. Michel'le did not think the apology was genuine and said she believed he released the statement to protect his brand. \"He apologized to the public. I don't think that was an apology to me, because if it was, he would've either called me without the public and said'Michel'le, I am so sorry for what I did to you 20-something years ago,' that's an apology\", she said.", indent: true },
  ],

  albums: [
    { title: "Michel'le", year: 1989, link: "https://music.youtube.com/browse/MPREb_IZkMnxteWTq" },
    { title: "Hung Jury", year: 1998, link: "https://music.youtube.com/playlist?list=PLzXn8cAHEDCjmahEJGJWPyHdPFjQeAiZZ" },
  ]
}
