export default {
  id: "Groove Theory",
  name: "Groove Theory",

  images: [
    "/src/images/Groove Theory/0_rd3H5AbUe-GzWu4A.jpg",
    "/src/images/Groove Theory/9962989.jpeg",
    "/src/images/Groove Theory/Groove_Theory_-_Groove_Theory_album_cover.jpg",
    "/src/images/Groove Theory/Tell_Me_cover_art.jpeg",
  ],

  videoIds: [
    "THtqUDitQ4I",
    "lhL1lUzmjcs",
    "TjRZ41pM2aM",
  ],

  biography: [
    { text: "Groove Theory is an R&B/hip-hop duo consisting of singer Amel Larrieux and rapper/former Mantronix group member Bryce Wilson.", indent: true },
    { text: "The duo started in 1993 when Bryce met Amel (who was working as a receptionist for Rondo Music in New York) through a friend. The two signed a record deal with Epic Records and in 1995, Groove Theory released their self-titled debut album which peaked at #69 on the Billboard 200 and #14 on Billboard’s R&B Albums chart. The duo’s first single and biggest hit to date “Tell Me” which peaked at #5 on the Billboard Hot 100, #2 on Billboard’s Rhythmic Top 40 chart, #21 on Billboard’s Top 40 Mainstream chart, #2 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart and #3 on Billboard’s Hot R&B Singles chart, staying on the chart for 38 weeks. The follow-up single released from the album “Keep Tryin'” peaked at #64 on the Billboard Hot 100, #29 on Billboard’s Rhythmic Top 40 chart, #36 on Billboard’s Hot Dance Music/Maxi-Singles Sales chart and #24 on Billboard’s Hot R&B Singles chart, staying on the chart for 18 weeks.", indent: true },
    { text: "The last single from the album “Baby Luv” peaked at #65 on the Billboard Hot 100, #14 on Billboard’s Rhythmic Top 40 chart, #18 on Billboard’s Hot Dance Music/Maxi-Singles chart and #23 on Billboard’s Hot R&B Singles chart, staying on the chart for 17 weeks.", indent: true },
    { text: "In 1999, Amel left Groove Theory to start her solo career and was replaced by Makeda Davis. The group left Epic Records and signed with Columbia Records.", indent: true },
    { text: "The duo recorded a new album entitled “The Answer” which was supposed to be released in 2001, but Bryce asked to be released from the label due to Columbia Records’ track record with urban music projects at the time & the album was never released.", indent: true },
    { text: "The only single released from the album was “4Shure” which managed to peak at #97 on Billboard’s Hot R&B/Hip-Hop Singles & Tracks chart, staying on the chart for only a week. Amel started her solo career by releasing her debut album “Infinite Possibilities” in 2000 and had a minor hit with the single “Get Up” which peaked at #97 on the Billboard Hot 100 and #37 on Billboard’s Hot R&B/Hip-Hop Singles & Tracks chart, staying on the chart for 20 weeks. In 2003, Amel started her own independent record label, Blisslife Records where she released her next three albums “Bravebird” (2004), “Morning” (2006), and “Lovely Standards” (2007).", indent: true },
    { text: "In February of 2010, Amel and Bryce reunited and were working on their second official album, but it’s unknown what the album’s release date will be.", indent: true },
    { text: "In October of 2013, Amel released her fifth solo album “Ice Cream Everyday” on her own independent record label Blisslife.", indent: true },
  ],

  albums: [
    { title: "Groove Theory", year: 1995, link: "https://music.youtube.com/browse/MPREb_ncyQVUpEaz2" },
    { title: "The Answer", year: 2000, link: "https://www.youtube.com/watch?v=ygqJ2HbEEE4" },
  ]
}
